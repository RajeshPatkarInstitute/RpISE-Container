package com.archanpatkar.Stack;


public interface Stack 
{
    public void push(int val);
    public void pop();
}
