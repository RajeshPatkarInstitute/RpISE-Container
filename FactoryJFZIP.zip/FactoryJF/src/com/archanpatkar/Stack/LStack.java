
package com.archanpatkar.Stack;


public class LStack implements Stack{
    
    @Override
    public void push(int val){
        System.out.println("Push of LStack val = " + val);
    }
    @Override
    public void pop()
    {
        System.out.println("Pop of LSstack");
    }
    
    
}
